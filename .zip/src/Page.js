import React from 'react';
import image from './images/687_header.svg'
export default function Page(){
    return(
    <div className='page'>
        <h1>გამარჯობათ ყველას!</h1>
        <h5>ჩემი სახელია საბა, <span> მე ვარ Front-End დეველოპერი</span> </h5>
        <div className='btns'>
        <a href="https://www.facebook.com/saba.tsimintia22"><button>ფეისბუქი</button></a>
        <a href="https://www.instagram.com/saba_tsimintia/"><button>ინსტაგრამი</button></a>
        </div>
        <div className='img'>
            <img src={image} alt =""/>
        </div>
        
    </div>
    )
}