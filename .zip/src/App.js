import About from './About';
import './App.css';
import Header from './Header';
import Myskills from './Myskills';
import Page from './Page';



function App() {
  return (
    <div className="App">
      
      <Header></Header>
      <Page></Page>
      <About></About>
      <Myskills></Myskills>

   
       
    </div>
        
    

  );
}

export default App;
















