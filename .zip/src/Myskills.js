import cssimg from './images/css.png'
import htmlimg from './images/html.png'
import jsimg from './images/js.png'
import reactimg from './images/react.png'
import tailimg from './images/tailwand.png'
import gitimg from './images/github.png'
import nodeimg from './images/node.png'
import pythonimg from './images/python.png'
import jqueryimg from './images/jquery.png'

 export default function Myskills(){
    return(
        <div className='btns2'>
            <div className='mskills'>
                <h1><span>My</span> Skills</h1>
            </div>


        <button className='htmlbtn'>
            <div className='html-img'>
                <img src={htmlimg}></img>
            </div>
        </button>


        <button className='cssbtn'>
            <div className='css-img'>
                <img src={cssimg}></img>
            </div>
        </button>


        <button className='jsbtn'>
            <div className='js-img'>
                <img src={jsimg}></img>
            </div>
        </button>


        <button className='reactbtn'>
            <div className='react-img'>
                <img src={reactimg}></img>
            </div>
        </button>


        <button className='nodebtn'>
            <div className='node-img'>
                <img src={nodeimg}></img>
            </div>
        </button>


        <button className='pythonbtn'>
            <div className='python-img'>
                <img src={pythonimg}></img>
            </div>
        </button>


        <button className='tailwandbtn'>
            <div className='tailwand-img'>
                <img src={tailimg}></img>
            </div>
        </button>


        <button className='gitbtn'>
            <div className='git-img'>
                <img src={gitimg}></img>
            </div>
        </button>

        <button className='jqbtn'>
            <div className='jq-img'>
                <img src={jqueryimg}></img>
            </div>
        </button>













            
        </div>
    )
}