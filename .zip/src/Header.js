import React, { useState, useEffect } from 'react'
function Header() {

  const [header, setHeader] = useState("header")

  const listenScrollEvent = (event) => {
    if (window.scrollY < 73) {
      return setHeader("header")
    } else if (window.scrollY > 70) {
      return setHeader("header2")
    } 
  }
  
  useEffect(() => {
    window.addEventListener('scroll', listenScrollEvent);
  
    return () =>
      window.removeEventListener('scroll', listenScrollEvent);
  }, []);
  return (
    
    <header className={header}>
       <h3 clasName='logo'><span>ჩემი </span> პორტფოლიო</h3>
      <nav>
       
          <button>მთავარი</button>
          <button>ჩემს შესახებ</button>
          <button>სკილები</button>
          <button>ნამუშევრები</button>
          
          
        
      </nav>
      <button className='contact' >კონტაქტი</button>
    </header>
    
  );
}

export default Header;